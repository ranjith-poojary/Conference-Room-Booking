package com.conference_room_application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConferencesRoomApplicationTests {

	@Test
	void contextLoads() {
	}

}
