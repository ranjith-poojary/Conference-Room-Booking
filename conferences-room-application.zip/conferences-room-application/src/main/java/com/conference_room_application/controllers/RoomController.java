package com.conference_room_application.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.conference_room_application.entitys.RoomDetails;
import com.conference_room_application.services.RoomService;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@CrossOrigin(origins="*")

public class RoomController {
    @Autowired
    private RoomService roomService;

    @PostMapping
    public ResponseEntity<RoomDetails> addRoom(@RequestBody RoomDetails room) {
        return ResponseEntity.ok(roomService.addRoom(room));
    }

    @GetMapping
    public ResponseEntity<List<RoomDetails>> getAllRooms() {
        return ResponseEntity.ok(roomService.getAllRooms());
    }
}

