package com.conference_room_application.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.conference_room_application.entitys.Admin;
import com.conference_room_application.services.AdminService;

@RestController
@RequestMapping("/api/admins")
@CrossOrigin(origins="*")
public class AdminController {
    @Autowired
    private AdminService adminService;

    @PostMapping("/login")
    public ResponseEntity<Admin> loginAdmin(@RequestBody Admin admin) {
        Admin foundAdmin = adminService.findByUsername(admin.getUsername());
        if (foundAdmin != null && foundAdmin.getPassword().equals(admin.getPassword())) {
            return ResponseEntity.ok(foundAdmin);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
}