package com.conference_room_application.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.conference_room_application.entitys.BookingDetails;

public interface BookingRepository extends JpaRepository<BookingDetails, Long> {
	
}