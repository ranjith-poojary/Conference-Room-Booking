package com.conference_room_application.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.conference_room_application.entitys.Admin;

public interface AdminRepository extends JpaRepository<Admin, String> {
    Admin findByUsername(String username);
}