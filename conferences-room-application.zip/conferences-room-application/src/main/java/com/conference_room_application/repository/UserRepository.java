package com.conference_room_application.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.conference_room_application.entitys.UserDetails;
public interface UserRepository extends JpaRepository<UserDetails, Long>
{
    UserDetails findByUsernameAndPassword(String username,String password);
}