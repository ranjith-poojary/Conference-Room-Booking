package com.conference_room_application.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.conference_room_application.entitys.RoomDetails;

public interface RoomRepository extends JpaRepository<RoomDetails, Long> {
}