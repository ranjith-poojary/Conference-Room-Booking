package com.conference_room_application.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conference_room_application.entitys.RoomDetails;
import com.conference_room_application.repository.RoomRepository;

import java.util.List;

@Service
public class RoomService {
	@Autowired
	 private RoomRepository roomRepository;

	    public RoomDetails addRoom(RoomDetails room) {
	        return roomRepository.save(room);
	    }

	    public List<RoomDetails> getAllRooms() {
	        return roomRepository.findAll();
	    }
	}