package com.conference_room_application.services;

import com.conference_room_application.entitys.UserDetails;
import com.conference_room_application.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public UserDetails register(UserDetails user) {
        // Registration logic
        return userRepository.save(user);
    }

    public UserDetails login(String username, String password) {
        // Login logic
        return userRepository.findByUsernameAndPassword(username, password);
    }

    public List<UserDetails> getAllUsers() {
        return userRepository.findAll();
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
