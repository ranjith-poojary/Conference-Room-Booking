package com.conference_room_application.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conference_room_application.entitys.BookingDetails;
import com.conference_room_application.repository.BookingRepository;

import java.util.List;

@Service
public class BookingService {
    @Autowired
    private BookingRepository bookingRepository;

    public BookingDetails bookRoom(BookingDetails booking) {
        return bookingRepository.save(booking);
    }

    public List<BookingDetails> getAllBookings() {
        return bookingRepository.findAll();
    }

    // New method to delete a booking
    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }

    // New method to update a booking
    public BookingDetails updateBooking(BookingDetails bookingDetails) {
        return bookingRepository.save(bookingDetails); 
    }
}